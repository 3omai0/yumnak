"use client";
import { motion } from "motion/react";
import Link from "next/link";

export function Navbar() {
  return (
    <motion.header 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 inset-x-0 z-50 flex items-center justify-between px-6 py-6 md:px-10 border-b border-neutral-200 bg-white/80 backdrop-blur-md"
    >
      <div className="flex items-center gap-2">
        <div className="flex items-center justify-center">
            {/* Custom SVG logo resembling the YOMNAK node pattern */}
            <svg width="40" height="30" viewBox="0 0 100 60" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-brand">
              <path d="M10 40h10a10 10 0 0010-10V20a10 10 0 0110-10h10a10 10 0 0110 10v20a10 10 0 0010 10h10a10 10 0 0010-10V20" stroke="currentColor" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/>
              <rect x="5" y="32" width="16" height="16" rx="4" fill="currentColor"/>
              <rect x="25" y="12" width="16" height="16" rx="4" fill="currentColor"/>
              <rect x="45" y="32" width="16" height="16" rx="4" fill="currentColor"/>
              <rect x="65" y="12" width="16" height="16" rx="4" fill="currentColor"/>
              <rect x="85" y="12" width="16" height="16" rx="4" fill="currentColor"/>
              <rect x="35" y="5" width="6" height="6" rx="2" fill="currentColor" className="opacity-50"/>
              <rect x="55" y="50" width="8" height="8" rx="2" fill="currentColor" className="opacity-50"/>
              <rect x="80" y="35" width="8" height="8" rx="2" fill="currentColor" className="opacity-50"/>
            </svg>
        </div>
        <div className="flex flex-col">
          <span className="text-2xl font-bold tracking-widest text-brand uppercase leading-none font-mono">YOMNAK</span>
          <span className="text-[10px] text-neutral-500 tracking-wider">Leading you to Success</span>
        </div>
      </div>
      
      <nav className="hidden md:flex gap-8 text-sm font-medium text-neutral-600">
        <Link href="#services" className="hover:text-brand transition-colors">الخدمات</Link>
        <Link href="#projects" className="hover:text-brand transition-colors">المشاريع</Link>
        <Link href="#methodology" className="hover:text-brand transition-colors">المنهجية</Link>
        <Link href="#about" className="hover:text-brand transition-colors">عن الشركة</Link>
      </nav>

      <button className="px-5 py-2 bg-brand text-white text-sm font-semibold rounded-full hover:bg-brand-dark transition-colors shadow-sm">
        ابدأ مشروعك
      </button>
    </motion.header>
  );
}
