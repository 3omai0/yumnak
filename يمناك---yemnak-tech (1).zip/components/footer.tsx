export function Footer() {
  return (
    <footer className="px-6 md:px-10 py-8 border-t border-neutral-200 flex flex-col md:flex-row items-center justify-between text-[11px] text-neutral-500 font-mono tracking-widest relative z-10 w-full bg-white uppercase">
      <div className="mb-4 md:mb-0">&copy; 2024 YOMNAK. All rights reserved.</div>
      <div className="flex gap-6">
        <span>الرياض، المملكة العربية السعودية</span>
        <span className="text-neutral-800 font-semibold">hello@yomnak.com</span>
      </div>
    </footer>
  );
}
